package net.androidbootcamp.traveltoast;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );



        setTitle ( "10 Destinations" );

        String[] country = {"Thailand", "Greece", "Spain", "Italy", "France", "Japan", "Switzerland", "United Kingdom", "Mexico", "Dubai",};

        ListAdapter countryAdapter = new ArrayAdapter <String> ( this, android.R.layout.simple_list_item_1, country );

        ListView countryImageListView = (ListView ) findViewById ( R.id.countryListView );
        countryImageListView.setAdapter ( countryAdapter );


        countryImageListView.setOnItemClickListener (
                new AdapterView.OnItemClickListener () {
                    @Override
                    public void onItemClick(AdapterView <?> parent, View view, int position, long id) {
                        String country = String.valueOf ( parent.getItemAtPosition ( position ) );
                        Toast.makeText ( MainActivity.this, country, Toast.LENGTH_SHORT ).show ();

                        //2 Toast.makeText(MainActivity.this, country, Toast.LENGTH_LONG).show();

                        //3 Toast.makeText(MainActivity.this, String.valueOf(position), Toast.LENGTH_LONG).show();

                        LayoutInflater inflater = getLayoutInflater ();
                        View layout = inflater.inflate ( R.layout.custom_toast,
                                ( ViewGroup ) findViewById ( R.id.custom_toast_container ) );
                        TextView text = ( TextView ) layout.findViewById ( R.id.text );
                        text.setText ( country + " in da house!" );
                        Toast toast = new Toast ( getApplicationContext () );
                        toast.setGravity ( Gravity.CENTER_VERTICAL, 0, 400 );
                        toast.setDuration ( Toast.LENGTH_LONG );
                        toast.setView ( layout );
                        toast.show ();

                        switch (position) {
                            case 0:
                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://www.touropia.com/tourist-attractions-in-australia/" ) ) );

                                break;
                            case 1:
                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://themysteriousworld.com/top-10-most-popular-tourist-attractions-of-france/" ) ) );

                                break;
                            case 2:
                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://www.touropia.com/tourist-attractions-in-greece/" ) ) );

                                break;
                            case 3:
                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://www.italianbreaks.com/italy-destinations-top-10-tourist-attractions-in-italy/" ) ) );
                                break;
                            case 4:
                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://www.touropia.com/tourist-attractions-in-japan/" ) ) );
                                break;
                            case 5:

                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://www.touropia.com/tourist-attractions-in-mexico-city/" ) ) );
                                break;
                            case 6:
                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://www.touropia.com/tourist-attractions-in-spain/" ) ) );
                                break;
                            case 7:
                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://www.touropia.com/tourist-attractions-in-switzerland/" ) ) );
                                break;
                            case 8:
                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://www.planetware.com/tourist-attractions/thailand-tha.htm" ) ) );
                                break;
                            case 9:
                                startActivity ( new Intent ( Intent.ACTION_VIEW, Uri.parse ( "https://www.visitbritainshop.com/world/articles/top-10-english-tourist-destinations/" ) ) );
                                break;
                        }

                    }
                }
        );
    }
}

